<?php
    	App::uses('AppModel', 'Model');
    /**
     * Tag Model
     *
     */
    class Tag extends AppModel {
    
    /**
     * Display field
     *Label
     * @var string
     */
      public $displayField = 'label';
      
      
      
      
  public $validate = array(
    'nome' => array(
      'notempty' => array(
        'rule' => array('notBlank'),
      ),
    )
  );
 }
?>


