<?php
	class TagsController extends AppController {
    public $helpers = array("Form", "Html");
    
    
    public function index() {
        $this->set("title", "Tags");
     
        $tags = $this->Tag->find('all');
        $this->set('tags', $tags);
    }
    
    
    public function adicionar() {
        $this->set('title', 'Adicionar tag');
 
        if ($this->request->is("post")) {
            $this->Tag->create();
 
            if ($this->Tag->saveAssociated($this->request->data)) {
                $this->Session->setFlash(__("Registro salvo com sucesso."));
                $this->redirect(array("action" => '/index/'));
            } else {
                $this->Session->setFlash(__("Erro: não foi possível salvar o registro."));
                $this->redirect(array("action" => '/adicionar/'));
            }
        }
    }
    
   public function editar($id = NULL) {
        $this->set("title", "Editar tag");
        $this->Tag->id = $id;
        if (!$this->Tag->exists()) {
            throw new NotFoundException(__('Registro não encontrado.'));
        }
 
        if ($this->request->is('post') || $this->request->is('put')) {
            if ($this->Tag->saveAssociated($this->request->data)) {
                $this->Session->setFlash(__('Registro salvo com sucesso.'));
                $this->redirect(array('action' => '/index/'));
            } else {
                $this->Session->setFlash(__('Erro: não foi possível salvar o registro.'));
            }
        } else {
            $this->request->data = $this->Tag->read(NULL, $id);
        }
    }
    
    
    public function excluir($id = NULL) {
        if (!$this->request->is('get')) {
            throw new MethodNotAllowedException();
        }
        $this->Tag->id = $id;
        if (!$this->Tag->exists()) {
            throw new NotFoundException(__('Registro não encontrado.'));
        }
        if ($this->Tag->delete()) {
            $this->Session->setFlash(__('Registro excluído com sucesso.'));
            $this->redirect(array('action' => '/index/'));
        }
        $this->Session->setFlash(__('Erro: não foi possível excluir o registro.'));
        $this->redirect(array('action' => '/index/'));
    } 
    
    
    
}
?>